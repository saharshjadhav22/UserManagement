﻿using UserManagement.Models;

namespace UserManagement.DTOs
{
    public record UserDto(Guid Id, string? Name, string UserName, string Email, Address Address, string Phone, string Website, Company Company);
    public record CreateUserDto(string Name, string UserName, string Email, Address Address, string Phone, string Website, Company Company);
    public record UpdateUserDto(string Name, string UserName, string Email, Address Address, string Phone, string Website, Company Company);

}
