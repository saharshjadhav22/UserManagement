﻿using UserManagement.Models;

namespace UserManagement.DTOs
{
    public static class Extensions
    {
        public static UserDto AsDto(this User user)
        {
            return new UserDto(user.Id, user.Name, user.UserName, user.Email, user.Address, user.Phone, user.Website, user.Company);
        }
    }
}
