﻿using UserManagement.Models;

namespace UserManagement.Core
{
    /// <summary>
    /// User repository Interface
    /// </summary>
    public interface IUserRepository
    {
        /// <summary>
        /// Get All User Details
        /// </summary>
        /// <returns>User details</returns>
        Task<IEnumerable<User>> GetUserAsync();

        /// <summary>
        /// Get Specific User Details
        /// </summary>
        /// <param name="id">User ID</param>
        /// <returns>User details</returns>
        Task<User> GetUserAsync(Guid id);

        /// <summary>
        /// Create New User
        /// </summary>
        /// <param name="user">User details</param>
        /// <returns>Created user details</returns>
        Task CreateUserAsync(User user);

        /// <summary>
        /// Update existing user
        /// </summary>
        /// <param name="user">User details</param>
        Task UpdateUserAsync(User user);

        /// <summary>
        /// Delete User
        /// </summary>
        /// <param name="id">User id</param>
        Task DeleteUserAsync(Guid id);

    }
}
