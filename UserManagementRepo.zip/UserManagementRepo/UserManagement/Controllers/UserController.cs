﻿using Microsoft.AspNetCore.Mvc;
using UserManagement.Core;
using UserManagement.DTOs;
using UserManagement.Models;


namespace UserManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository repository;
        // private readonly ILogger<UserController> logger;

        public UserController(IUserRepository repository)//, ILogger<UserController> logger)
        {
            this.repository = repository;
            //this.logger = logger;
        }

        /// <summary>
        /// Get all User details
        /// </summary>
        /// <returns>List of Users</returns>        
        [HttpGet]
        public async Task<IEnumerable<UserDto>> GetUserAsync()
        {
            string name = string.Empty;
            var users = (await repository.GetUserAsync())
                        .Select(user => user.AsDto());

            if (!string.IsNullOrWhiteSpace(name))
            {
                users = users.Where(user => user.Name.Contains(name, StringComparison.OrdinalIgnoreCase));
            }

            // logger.LogInformation($"{DateTime.UtcNow.ToString("hh:mm:ss")}: Retrieved {users.Count()} users");

            return users;
        }

        /// <summary>
        /// Get specific User details by id
        /// </summary>
        /// <param name="id">UserId</param>
        /// <returns>User</returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<UserDto>> GetUserAsync(Guid id)
        {
            var item = await repository.GetUserAsync(id);

            if (item is null)
            {
                return NotFound();
            }

            return item.AsDto();
        }

        /// <summary>
        /// Create new User
        /// </summary>
        /// <param name="userDto">UserDetails</param>
        /// <returns>Created User</returns>
        [HttpPost]
        public async Task<ActionResult<UserDto>> CreateUserAsync(CreateUserDto userDto)
        {
            User user = new()
            {
                Id = Guid.NewGuid(),
                Name = userDto.Name,
                UserName = userDto.UserName,
                Email = userDto.Email,
                Address = userDto.Address,
                Phone = userDto.Phone,
                Website = userDto.Website,
                Company = userDto.Company
            };

            await repository.CreateUserAsync(user);

            return Ok(CreatedAtAction(nameof(CreateUserAsync), new { id = user.Id }, user.AsDto()));
        }

        /// <summary>
        /// Update existing User
        /// </summary>
        /// <param name="id">User id</param>
        /// <param name="userDto">UserDetails</param>
        /// <returns>Updated User</returns>
        [HttpPut]
        public async Task<ActionResult> UpdateUserAsync(Guid id, UpdateUserDto userDto)
        {
            var existingUser = await repository.GetUserAsync(id);

            if (existingUser is null)
            {
                return NotFound();
            }

            existingUser.Name = userDto.Name;
            existingUser.UserName = userDto.UserName;
            existingUser.Email = userDto.Email;
            existingUser.Address = userDto.Address;
            existingUser.Phone = userDto.Phone;
            existingUser.Website = userDto.Website;
            existingUser.Company = userDto.Company;

            await repository.UpdateUserAsync(existingUser);

            return NoContent();
        }

        /// <summary>
        /// Delete specific User
        /// </summary>
        /// <param name="id">UserId</param>
        /// <returns>UserDetails</returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteUserAsync(Guid id)
        {
            var existingItem = await repository.GetUserAsync(id);

            if (existingItem is null)
            {
                return NotFound();
            }

            await repository.DeleteUserAsync(id);

            return NoContent();
        }
    }
}
