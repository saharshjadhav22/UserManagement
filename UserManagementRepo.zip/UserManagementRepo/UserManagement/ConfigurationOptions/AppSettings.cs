﻿namespace UserManagement.ConfigurationOptions
{
    /// <summary>
    /// Application setting file for Database configuration
    /// </summary>
    public class AppSettings
    {
        /// <summary>
        /// Collection Name
        /// </summary>
        public string UsersCollectionName { get; set; } = String.Empty;

        /// <summary>
        /// Database Connection String
        /// </summary>
        public string ConnectionString { get; set; } = String.Empty;

        /// <summary>
        /// Database Name
        /// </summary>
        public string DatabaseName { get; set; } = String.Empty;
    }


}
