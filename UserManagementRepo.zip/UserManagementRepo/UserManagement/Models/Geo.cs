﻿namespace UserManagement.Models
{
    /// <summary>
    /// Geographical details model class
    /// </summary>
    public class Geo
    {
        /// <summary>
        /// Latitude details
        /// </summary>
        public string Lat { get; set; } = String.Empty;

        /// <summary>
        /// Longitude details
        /// </summary>
        public string Lng { get; set; } = String.Empty;
    }
}
