﻿namespace UserManagement.Models
{
    /// <summary>
    /// User details model class
    /// </summary>
   // [BsonIgnoreExtraElements]
    public class User
    {
        public User()
        {
            Address = new Address();
            Company = new Company();
        }

        /// <summary>
        /// User Id
        /// </summary>
        //[BsonId]
        //[BsonRepresentation(BsonType.ObjectId)]
        // public string Id { get; set; } = String.Empty;
        public Guid Id { get; set; }

        /// <summary>
        /// Name
        /// </summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>
        /// User Name
        /// </summary>
        public string UserName { get; set; } = string.Empty;

        /// <summary>
        /// Email Id
        /// </summary>
        public string Email { get; set; } = string.Empty;

        /// <summary>
        /// Address Details
        /// </summary>
        public Address Address { get; set; }

        /// <summary>
        /// Phone number
        /// </summary>
        public string Phone { get; set; } = string.Empty;

        /// <summary>
        /// Website details
        /// </summary>
        public string Website { get; set; } = string.Empty;

        /// <summary>
        /// Company Details
        /// </summary>
        public Company Company { get; set; }
    }
}
