﻿namespace UserManagement.Models
{
    /// <summary>
    /// Address model class
    /// </summary>
    public class Address
    {
        /// <summary>
        /// Street
        /// </summary>
        public string Street { get; set; } = String.Empty;

        /// <summary>
        /// Suite
        /// </summary>
        public string Suite { get; set; } = String.Empty;

        /// <summary>
        /// City
        /// </summary>
        public string City { get; set; } = String.Empty;

        /// <summary>
        /// Zipcode
        /// </summary>
        public string ZipCode { get; set; } = String.Empty;

        /// <summary>
        /// Geo details
        /// </summary>
        public Geo? Geo { get; set; }
    }
}
