﻿namespace UserManagement.Models
{
    /// <summary>
    /// Company model class
    /// </summary>
    public class Company
    {
        /// <summary>
        /// Company Name
        /// </summary>
        public string Name { get; set; } = String.Empty;

        /// <summary>
        /// Catch Phrase
        /// </summary>
        public string CatchPhrase { get; set; } = String.Empty;

        /// <summary>
        /// Bs
        /// </summary>
        public string BS { get; set; } = String.Empty;
    }
}
