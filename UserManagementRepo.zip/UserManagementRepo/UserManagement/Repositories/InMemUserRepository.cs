﻿using UserManagement.Core;
using UserManagement.Models;

namespace UserManagement.Repositories
{
    public class InMemUserRepository: IUserRepository
    {
        private readonly List<User> users = new()
        {
            new User { Id = Guid.NewGuid(), Name = "Saharsh", UserName = "saharshj", Email = "saharshj@gmail.com",Phone="9999900000",Website="www.abc.com" },
            new User { Id = Guid.NewGuid(), Name = "Sachin", UserName = "sachind", Email = "sachind@gmail.com",Phone="9999262500",Website="www.dsd.com" },
            new User { Id = Guid.NewGuid(), Name = "CK", UserName = "cky", Email = "cky@gmail.com",Phone="9625900000",Website="www.hsgs.com" }
        };

        public async Task<IEnumerable<User>> GetUserAsync()
        {
            return await Task.FromResult(users);
        }

        public async Task<User> GetUserAsync(Guid id)
        {
            var item = users.Where(item => item.Id == id).SingleOrDefault();
#pragma warning disable CS8603 // Possible null reference return.
            return await Task.FromResult(item);
#pragma warning restore CS8603 // Possible null reference return.
        }

        
        public async Task CreateUserAsync(User item)
        {
            users.Add(item);
            await Task.CompletedTask;
        }

        public async Task UpdateUserAsync(User item)
        {
            var index = users.FindIndex(existingItem => existingItem.Id == item.Id);
            users[index] = item;
            await Task.CompletedTask;
        }

        public async Task DeleteUserAsync(Guid id)
        {
            var index = users.FindIndex(existingItem => existingItem.Id == id);
            users.RemoveAt(index);
            await Task.CompletedTask;
        }
    }
}
