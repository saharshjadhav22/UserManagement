﻿using MongoDB.Bson;
using MongoDB.Driver;
using UserManagement.Core;
using UserManagement.Models;

namespace UserManagement.Repositories
{
    /// <summary>
    /// User repository class to expose CRUD operation methods
    /// </summary>
    public class MongoDbUserRepository : IUserRepository
    {
        private const string databaseName = "MyUserDB";
        private const string collectionName = "User";
        private readonly IMongoCollection<User> usersCollection;
        private readonly FilterDefinitionBuilder<User> filterBuilder = Builders<User>.Filter;

        public MongoDbUserRepository(IMongoClient mongoClient)
        {
            //var database = mongoClient.GetDatabase(settings.DatabaseName);
            //usersCollection = database.GetCollection<User>(settings.UsersCollectionName);
            IMongoDatabase database = mongoClient.GetDatabase(databaseName);
            usersCollection = database.GetCollection<User>(collectionName);
        }

        /// <summary>
        /// Create user
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>        
        public async Task CreateUserAsync(User user)
        {
            await usersCollection.InsertOneAsync(user);
        }

        /// <summary>
        /// Get all user details
        /// </summary>
        /// <returns></returns>        
        public async Task<IEnumerable<User>> GetUserAsync()
        {
            return await usersCollection.Find(new BsonDocument()).ToListAsync();
        }

        /// <summary>
        /// Get user details by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<User> GetUserAsync(Guid id)
        {
            // var filter = filterBuilder.Eq(user => user.Id, id);
            // return await usersCollection.Find(filter).SingleOrDefaultAsync();
            return await usersCollection.Find(User => User.Id == id).SingleOrDefaultAsync();
            // return _users.Find(Users => Users.Id == id).FirstOrDefault();
        }

        /// <summary>
        /// Delete user
        /// </summary>
        /// <param name="id"></param>        
        public async Task DeleteUserAsync(Guid id)
        {
            var filter = filterBuilder.Eq(user => user.Id, id);
            await usersCollection.DeleteOneAsync(filter);
        }

        /// <summary>
        /// Update user
        /// </summary>
        /// <param name="user"></param>        
        public async Task UpdateUserAsync(User user)
        {
            var filter = filterBuilder.Eq(existingItem => existingItem.Id, user.Id);
            await usersCollection.ReplaceOneAsync(filter, user);
        }
    }
}
