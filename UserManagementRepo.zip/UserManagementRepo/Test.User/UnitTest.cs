using Microsoft.AspNetCore.Mvc;
using Moq;
using UserManagement.Controllers;
using UserManagement.Core;
using UserManagement.DTOs;
using UserManagement.Models;

namespace TestUser
{
    public class UnitTest
    {
        public Mock<IUserRepository> mock = new();

        //[Fact]
        //public async Task User_GetAllUsers_Return_OkResult()
        //{
        //    //Arrange
        //    List<User> user = new()
        //    {
        //        UserData()
        //    };
            
        //    mock.Setup(p => p.GetUserAsync()).Returns(users);
        //    UserController usr = new(mock.Object);

        //    //Act
        //    var result = await usr.GetUserAsync();

        //    //Assert
        //    Assert.IsType<OkObjectResult>(result as OkObjectResult);
        //}

        //[Fact]
        //public void User_GetAllUsers_Return_NotFoundResult()
        //{
        //    //Arrange
        //    List<User> user = new() { };
        //    mock.Setup(p => p.GetUserAsync()).Returns(user);
        //    UserController usr = new(mock.Object);

        //    //Act
        //    var result = usr.GetUserAsync();

        //    //Assert
        //    Assert.IsType<NotFoundObjectResult>(result.Result as NotFoundObjectResult);
        //}

        //[Fact]
        //public void User_GetUserById_Return_OkResult()
        //{
        //    //Arrange
        //    var user = UserData();
        //    mock.Setup(p => p.GetUserAsync("1000")).Returns(user);
        //    UserController usr = new(mock.Object);

        //    //Act
        //    var result = usr.GetUserAsync("1000");

        //    //Assert
        //    Assert.IsType<OkObjectResult>(result.Result as OkObjectResult);
        //}

        //[Fact]
        //public void User_GetUserById_Return_NotFoundResult()
        //{
        //    //Arrange
        //    var user = UserData();
        //    mock.Setup(p => p.GetUserAsync("1000")).Returns(user);
        //    UserController usr = new(mock.Object);

        //    //Act            
        //    var result = usr.GetUserAsync("1001");

        //    //Assert
        //    Assert.IsType<NotFoundObjectResult>(result.Result as NotFoundObjectResult);
        //    Assert.NotNull(result);
        //}

        //[Fact]
        //public void User_GetUserById_Return_BadRequestResult()
        //{
        //    //Arrange  
        //    var controller = new UserController(mock.Object);
        //    string? id=String.Empty;

        //    //Act  
        //    var data = controller.GetUserAsync(id);

        //    //Assert  
        //    Assert.IsType<BadRequestObjectResult>(data.Result as BadRequestObjectResult);
        //}

        //[Fact]
        //public void User_CreateUser_Return_OkResult()
        //{
        //    //Arrange
        //    var user = UserData();
        //    mock.Setup(p => p.CreateUserAsync(user)).Returns(user);
        //    UserController usr = new(mock.Object);

        //    //Act
        //    var result = usr.CreateUserAsync(user);

        //    //Assert
        //    Assert.NotNull(result.Result);
        //    Assert.Equal("SaharshJ",user.UserName);
        //    Assert.Equal("saharshj@gmail.com", user.Email);           
        //    Assert.IsType<OkObjectResult>(result.Result as OkObjectResult);
        //}               

        //[Fact]
        //public void User_UpdateUser_Return_OkResult()
        //{
        //    //Arrange
        //    var user = UserData();
        //    mock.Setup(p => p.GetUserAsync("1000")).Returns(user);

        //    //Act
        //    UserController usr = new(mock.Object);
        //    var result = usr.UpdateUserAsync(user);

        //    //Assert
        //    Assert.NotNull(result.Result);            
        //    Assert.IsType<OkResult>(result.Result as OkResult);
        //}

        //[Fact]
        //public void User_UpdateUser_Return_NotFoundResult()
        //{
        //    //Arrange
        //    var user = UserData();
        //    mock.Setup(p => p.GetUserAsync("1000")).Returns(user);

        //    //Act
        //    user.Id = "1001";
        //    UserController usr = new(mock.Object);
        //    var result = usr.UpdateUserAsync(user);

        //    //Assert
        //    Assert.IsType<NotFoundObjectResult>(result.Result as NotFoundObjectResult);
        //}

        //[Fact]
        //public void User_DeleteUser_Return_OkResult()
        //{
        //    //Arrange
        //    var user = UserData();
        //    mock.Setup(p => p.GetUserAsync("1000")).Returns(user);

        //    //Act
        //    UserController usr = new(mock.Object);
        //    var result = usr.DeleteUserAsync("1000");

        //    //Assert
        //    Assert.NotNull(user);
        //    Assert.IsType<OkObjectResult>(result.Result as OkObjectResult);
        //}

        //[Fact]
        //public void User_DeleteUser_Return_NotFoundResult()
        //{
        //    //Arrange
        //    var user = UserData();
        //    mock.Setup(p => p.GetUserAsync("1000")).Returns(user);

        //    //Act
        //    UserController usr = new(mock.Object);
        //    var result = usr.DeleteUserAsync("1001");

        //    //Assert
        //    Assert.NotNull(result.Result);
        //    Assert.IsType<NotFoundObjectResult>(result.Result as NotFoundObjectResult);
        //}

        //[Fact]
        //public void User_DeleteUser_Return_ValidateResult()
        //{
        //    //Arrange

        //    var user = UserData();
        //    mock.Setup(p => p.DeleteUserAsync(It.IsAny<Guid>()));

        //    //Act
        //    UserController usr = new(mock.Object);
        //    var result = usr.DeleteUserAsync(It.IsAny<Guid>());

        //    //Assert
        //    Assert.IsType<NotFoundObjectResult>(result.Result as NotFoundObjectResult);
        //}

        [Fact]
        public async Task GetItemAsync_WithUnexistingItem_ReturnsNotFound()
        {
            // Arrange
            mock.Setup(repo => repo.GetUserAsync(It.IsAny<Guid>()))
                .ReturnsAsync((User)null);

            var controller = new UserController(mock.Object);//, loggerStub.Object);

            // Act
            var result = await controller.GetUserAsync(Guid.NewGuid());

            // Assert
            //result.Result.Should().BeOfType<NotFoundResult>();
            Assert.IsType<NotFoundResult>(result.Result as NotFoundResult);
        }

        [Fact]
        public async Task GetUserAsync_WithExistingUser_ReturnsExpectedUser()
        {
            // Arrange
            User expectedItem = CreateRandomUser();

            mock.Setup(repo => repo.GetUserAsync(It.IsAny<Guid>()))
                .ReturnsAsync(expectedItem);

            var controller = new UserController(mock.Object);//, loggerStub.Object);

            // Act
            var result = await controller.GetUserAsync(Guid.NewGuid());

            // Assert
            //result.Value.Should().BeEquivalentTo(expectedItem);
            _ = result.Value.Equals(expectedItem);
        }

        [Fact]
        public async Task GetUsersAsync_WithExistingUsers_ReturnsAllUsers()
        {
            // Arrange
            var expectedUsers = new[] { CreateRandomUser(), CreateRandomUser(), CreateRandomUser() };

            mock.Setup(repo => repo.GetUserAsync())
                .ReturnsAsync(expectedUsers);

            var controller = new UserController(mock.Object);//, loggerStub.Object);

            // Act
            var actualUsers = await controller.GetUserAsync();

            // Assert

            actualUsers.Equals(expectedUsers);
            //actualUsers.Should().BeEquivalentTo(expectedUsers);
        }

        [Fact]
        public async Task GetUserAsync_WithMatchingUsers_ReturnsMatchingUsers()
        {
            // Arrange
            var allUser = new[]
            {
                new User(){ Name = "Potion"},
                new User(){ Name = "Antidote"},
                new User(){ Name = "Hi-Potion"}
            };

            //var nameToMatch = "Potion";

            mock.Setup(repo => repo.GetUserAsync())
                .ReturnsAsync(allUser);

            var controller = new UserController(mock.Object);//, loggerStub.Object);

            // Act
            IEnumerable<UserDto> foundItems = await controller.GetUserAsync();

            // Assert
            //foundItems.Contains.Should().OnlyContain(
            //    item => item.Name == allItems[0].Name || item.Name == allItems[2].Name
            //);

            foundItems.Select(ur => ur.Name == allUser[0].Name);
        }

        [Fact]
        public async Task CreateUserAsync_WithUserToCreate_ReturnsCreatedUser()
        {
            // Arrange

            var userToCreate = new CreateUserDto(
                Guid.NewGuid().ToString(),
                Guid.NewGuid().ToString(),
                "abc@gmail.com",
                new Address(),
                "988277772",
                "www.eee.com",
                new Company()
            );

            var controller = new UserController(mock.Object);//, loggerStub.Object);

            // Act
            var result = await controller.CreateUserAsync(userToCreate);

            // Assert
            var createdUser = (result.Result as CreatedAtActionResult).Value as UserDto;

            //userToCreate.Should().BeEquivalentTo(
            //    createdItem,
            //    options => options.ComparingByMembers<ItemDto>().ExcludingMissingMembers()
            //);
            //createdUser.Id.Should().NotBeEmpty();
            //createdUser.CreatedDate.Should().BeCloseTo(DateTimeOffset.UtcNow, 1000);
            Assert.NotEmpty(createdUser.Id.ToString());
            //Assert.Equal(result.Value.Name, createdUser.Name);
        }

        [Fact]
        public async Task UpdateItemAsync_WithExistingUser_ReturnsNoContent()
        {
            // Arrange
            User existingItem = CreateRandomUser();
            mock.Setup(repo => repo.GetUserAsync(It.IsAny<Guid>()))
                .ReturnsAsync(existingItem);

            var itemId = existingItem.Id;
            var itemToUpdate = new UpdateUserDto(
                Guid.NewGuid().ToString(),
                Guid.NewGuid().ToString(),
                "abc@gmail.com",
                new Address(),
                "988277772",
                "www.eee.com",
                new Company()
            );

            var controller = new UserController(mock.Object);//, loggerStub.Object);

            // Act
            var result = await controller.UpdateUserAsync(itemId, itemToUpdate);

            // Assert
            //result.Should().BeOfType<NoContentResult>();
            Assert.IsType<NoContentResult>(result as NoContentResult);
        }

        [Fact]
        public async Task DeleteUserAsync_WithExistingUser_ReturnsNoContent()
        {
            // Arrange
            var existingUser = CreateRandomUser();
            mock.Setup(repo => repo.GetUserAsync(It.IsAny<Guid>()))
                .ReturnsAsync(existingUser);

            var controller = new UserController(mock.Object);//, loggerStub.Object);

            // Act
            var result = await controller.DeleteUserAsync(existingUser.Id);

            // Assert
            Assert.IsType<NoContentResult>(result as NoContentResult);
        }

        [Fact]
        public async Task DeleteUserAsync_WithExistingUser_ReturnsNotFound()
        {
            // Arrange
            var existingUser = CreateRandomUser();
            mock.Setup(repo => repo.GetUserAsync(Guid.NewGuid()))
               .ReturnsAsync(existingUser);

            var controller = new UserController(mock.Object);

            Guid guid = Guid.NewGuid();
            // Act
            var result = await controller.DeleteUserAsync(guid);

            // Assert
            Assert.IsType<NotFoundResult>(result as NotFoundResult);
        }


        //private static User UserData()
        //{
        //    var user = new User()
        //    {
        //        Id = Guid.NewGuid(),
        //        Name = "Saharsh",
        //        UserName = "SaharshJ",
        //        Email = "saharshj@gmail.com",
        //        Phone = "9999900000",
        //        Website = "www.abc.com"
        //    };

        //    return user;
        //}
        private static User CreateRandomUser()
        {
            return new()
            {
                Id = Guid.NewGuid(),
                Name = "Saharsh",
                UserName = "SAH",
                Email = "abc@gmail.com",
                Phone = "9999900000",
                Website = "www.abc.com"
            };
        }
    }
}